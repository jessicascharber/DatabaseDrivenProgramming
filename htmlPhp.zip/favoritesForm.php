<html>
		<head>
	<title>Favorites Alphabetized</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles/custom.css" />
<link rel="stylesheet" href="themes/rasmussenthemeroller.min.css" />
<link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile.structure-1.4.5.min.css" />
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
<script src="javascript/storage.js"></script>
</head>
	<body>
		<div id="page" data-role="page" data-theme="b" >
	<div data-role="header" data-theme="b">
<h1>
	Favorites Alphabetized
		</h1>	</div>
				<div data-role="content">


 <h4><center><b> These are a few of my favorite things... <b><center></h4>

	<?php

						   $fav1= (isset($_POST['fav1'])    ? $_POST['fav1']   : '');
							 $fav2= (isset($_POST['fav2'])    ? $_POST['fav2']   : '');
							 $fav3= (isset($_POST['fav3'])    ? $_POST['fav3']   : '');
							 $fav4= (isset($_POST['fav4'])    ? $_POST['fav4']   : '');
							 $fav5= (isset($_POST['fav5'])    ? $_POST['fav5']   : '');
							 $fav6= (isset($_POST['fav6'])    ? $_POST['fav6']   : '');
							 $fav7= (isset($_POST['fav7'])    ? $_POST['fav7']   : '');





	$favorites = array("$fav1","$fav2","$fav3","$fav4","$fav5","$fav6","$fav7");

						sort($favorites);
						$alength = count($favorites);
						for($i = 0; $i < $alength; $i++) {
							$pattern = "/[a-zA-Z]/";
							if (preg_match($pattern, $favorites[$i])) {
								echo "*" . $favorites[$i] . " ";
							} else {
							echo "Invalid entry for favorite - " . $favorites[$i] . " Your entry must contain letters.";
							}
							echo "<br/><br/>";

						}

?>



				<div data-role="footer" data-theme="b">
	  <h4>Favorites App &copy; 2018</h4>
	</div>
	</body>
</html>
