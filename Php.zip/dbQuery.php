<?php
include 'configFile.php';
include 'connectOpenDb.php';

$sql= "SELECT firstName, lastName, city FROM familymembers";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "firstName: " . $row["firstName"]. "<br>";
        echo "lastName: " . $row["lastName"]. "<br>";
        echo "city: " . $row["city"]. "<br><hr>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);

?>
