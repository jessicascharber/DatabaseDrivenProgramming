<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = '';
$dbpass = '';
$dbname = 'jscharberdb';
?>
