<!DOCTYPE HTML>
<html>
    <head>
        <title>MY FIRST OFFICIAL PHP PAGE!</title>
    </head>
    <body>

        <?php
            echo '<p>                    MY FIRST OFFICIAL PHP PAGE!</p>';
            echo '<p>    This is my first official php page. I have included the required headings, paragraph and formatted text. I have never created original paragraph text or headings using php so, not having prior knowledge, I hope I have met your expectations. This page also includes sample data from my Family Information Database. I have run a query to the database, via FileZilla, in order to provide you with this data.<p>';


            echo '<p>                        DATABASE QUERY<p>';
        ?>

    </body>
</html><?php
include 'configFile.php';
include 'connectOpenDb.php';

$sql= "SELECT firstName, lastName, city FROM familymembers";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "firstName: " . $row["firstName"]. "<br>";
        echo "lastName: " . $row["lastName"]. "<br>";
        echo "city: " . $row["city"]. "<br><hr>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);

?>
